#include <iostream>
#include <fstream>
#include <map>

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;
    string dataFile = "frequency.dat";
    string inputFile = "CS210_Project_Three_Input_File.txt";

public:
    ItemTracker() {
        loadData();
    }

    void loadData() {
        ifstream file(inputFile);
        string itemName;
        int frequency;

        while (file >> itemName >> frequency) {
            itemFrequency[itemName] = frequency;
        }

        file.close();
    }

    void saveData() {
        ofstream file(dataFile);

        for (const auto& pair : itemFrequency) {
            file << pair.first << " " << pair.second << endl;
        }

        file.close();
    }

    void searchItem() {
        string itemName;
        cout << "Enter the item to search: ";
        cin >> itemName;

        if (itemFrequency.count(itemName) > 0) {
            cout << "Frequency of " << itemName << ": " << itemFrequency[itemName] << endl;
        }
        else {
            cout << "Item not found." << endl;
        }
    }

    void printItemFrequency() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void printHistogram() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }

    void run() {
        int choice;

        do {
            cout << "Menu:" << endl;
            cout << "1. Search for an item" << endl;
            cout << "2. Print item frequency" << endl;
            cout << "3. Print histogram" << endl;
            cout << "4. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
            case 1:
                searchItem();
                break;
            case 2:
                printItemFrequency();
                break;
            case 3:
                printHistogram();
                break;
            case 4:
                saveData();
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
            }

            cout << endl;
        } while (choice != 4);
    }
};

int main() {
    ItemTracker tracker;
    tracker.run();

    return 0;
}

