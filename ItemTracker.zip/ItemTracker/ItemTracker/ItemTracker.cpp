#include <iostream>
#include <fstream>
#include <map>

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;
    string dataFile = "frequency.dat";
    string inputFile = "CS210_Project_Three_Input_File.txt";

public:
    ItemTracker() {
        loadItemData();
    }

    void loadItemData() {
        ifstream inputFileStream(inputFile);
        string itemName;
        int frequency;

        while (inputFileStream >> itemName >> frequency) {
            itemFrequency[itemName] = frequency;
        }

        inputFileStream.close();
    }

    void saveItemData() {
        ofstream dataFileStream(dataFile);

        for (const auto& pair : itemFrequency) {
            dataFileStream << pair.first << " " << pair.second << endl;
        }

        dataFileStream.close();
    }

    void searchItemFrequency() {
        string itemName;
        cout << "Enter the item to search: ";
        cin >> itemName;

        if (itemFrequency.count(itemName) > 0) {
            cout << "Frequency of " << itemName << ": " << itemFrequency[itemName] << endl;
        }
        else {
            cout << "Item not found." << endl;
        }
    }

    void printItemFrequencyList() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void printItemFrequencyHistogram() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }

    void runProgram() {
        int choice;

        do {
            cout << "Menu:" << endl;
            cout << "1. Search for item frequency" << endl;
            cout << "2. Print item frequency list" << endl;
            cout << "3. Print item frequency histogram" << endl;
            cout << "4. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
            case 1:
                searchItemFrequency();
                break;
            case 2:
                printItemFrequencyList();
                break;
            case 3:
                printItemFrequencyHistogram();
                break;
            case 4:
                saveItemData();
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
            }

            cout << endl;
        } while (choice != 4);
    }
};

int main() {
    ItemTracker tracker;
    tracker.runProgram();

    return 0;
}

